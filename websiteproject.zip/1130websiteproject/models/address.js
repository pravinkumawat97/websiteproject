const mongoose=require('mongoose')

const addressSchema=mongoose.Schema({
    address:String,
    telephone:Number,
    whatsapp:Number,
    mobile:Number,
    email:String,
    linkedin:String,
    twitter:String,
    snapchat:String,
    instagram:String
 })


module.exports=mongoose.model('address',addressSchema)