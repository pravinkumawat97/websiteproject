const mongoose=require('mongoose')

const testiSchema=mongoose.Schema({
     img:{type:String,
        require:true,
        default:'avatar.jpg'
    },
     quotes:{type:String,require:true},
     name:{type:String,require:true},
     status:{type:String,default:'Unpublished'},
     postedDate:Date
 })

module.exports=mongoose.model('testi',testiSchema)