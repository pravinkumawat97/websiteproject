const Testi=require('../models/testi')
const Address=require('../models/address')

exports.testiform= async (req,res)=>{
      const addressrecord=await Address.findOne()
    res.render('testiform.ejs',{message:'',addressrecord})
}
exports.testiadd=(req,res)=>{
     try{    
     const {quotes,cname}=req.body
     const todaydate=new Date()
     if(req.file){
        const  filename=req.file.filename
        var record=Testi({quotes:quotes,name:cname,img:filename,postedDate:todaydate})
     }else{
        var record=Testi({quotes:quotes,name:cname,postedDate:todaydate})
     }    
     record.save()
     //console.log(record)
      const addressrecord= Address.findOne()
     res.render('testiform.ejs',{message:'Successfuly Review Has Been Given',addressrecord})
}catch(error){
     console.log(error.message)
}
}
exports.testiselection= async (req,res)=>{
     try{
   const  username=req.session.username
    const record=await Testi.find().sort({postedDate:-1})     
     const totalrecord=await Testi.count()
     const totalPublished=await Testi.count({status:'Published'})
     const totalUnpublished=await Testi.count({status:'Unpublished'})
    res.render('admin/testi.ejs',{username,record,totalrecord,totalPublished,totalUnpublished})
     }catch(error){
          console.log(error.message)
     }
}
exports.testidelete= async (req,res)=>{
     try{
    const id=req.params.id
    await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testi')
     }catch(error){
     console.log(error.message)
     }
}
exports.testistatusupdate= async (req,res)=>{
     try{
    const id=req.params.id
   const record=await Testi.findById(id)
   //console.log(record)
     let newstatus=null
   if(record.status=='Unpublished'){
        newstatus='Published'
   }else{
        newstatus='Unpublished'
   }
  await Testi.findByIdAndUpdate(id,{status:newstatus})
     res.redirect('/admin/testi')
}catch(error){
     console.log(error.message)
}
}
exports.searchstatus= async (req,res)=>{
     try{
     const  username=req.session.username
     const totalrecord=await Testi.count()
     const totalPublished=await Testi.count({status:'Published'})
     const totalUnpublished=await Testi.count({status:'Unpublished'})
     const {searchinput}=req.body      
     if(searchinput!==''){          
          var record=await Testi.find({status:searchinput})
     }else{
          record=await Testi.find({status:{$in:['Unpublished','Published']}})
     }
    
     res.render('admin/testi.ejs',{username,record,totalrecord,totalPublished,totalUnpublished})
     }catch(error){
          console.log(error.message)
     }
}