const Banner=require('../models/banner')
const Address=require('../models/address')

exports.bannerselection= async (req,res)=>{
    const username=req.session.username
    const record=await Banner.findOne() 
    //console.log(record)   
    const message=req.params.message
     res.render('admin/banner.ejs',{record,username,message})
  
}
exports.bannerupdateform= async(req,res)=>{
    try{
    const username=req.session.username
    const id=req.params.id
   const record= await Banner.findById(id)
   //console.log(record)
    res.render('admin/bannerupdateform',{username,record})
    }catch(error){
      console.log(error.message)
    }
}
exports.bannerupdate= async (req,res)=>{  
  try{ 
      const id=req.params.id
      const{title,desc,mdetail}=req.body
      if(req.file){
        const filename=req.file.filename
     await Banner.findByIdAndUpdate(id,{title:title,desc:desc,moredetails:mdetail,img:filename})
      }else{
        await Banner.findByIdAndUpdate(id,{title:title,desc:desc,moredetails:mdetail})
      }
      let message='Successfully Update'
     res.redirect(`/admin/banner/${message}`)
    }catch(error){
      console.log(error.message)
    }
}
exports.userbanner= async (req,res)=>{
   try{
    const record= await Banner.findOne()
    const addressrecord=await Address.findOne()
    res.render('banner.ejs',{record,addressrecord})
   }catch(error){
    console.log(error.message)
   }
}