const Query=require('../models/query')
const nodemailer=require('nodemailer')

exports.queryadd=(req,res)=>{
    try{
    const {email,query}=req.body
   const record=Query({email:email,query:query})
    record.save()
    //console.log(record)
    res.render('querymessage.ejs')
    }catch(error){
        console.log(error.message)
    }
}
exports.queryselection= async (req,res)=>{
  try{
   const  username=req.session.username
     const record=await Query.find().sort({status:-1})
    res.render('admin/query.ejs',{username,record})
  }catch(error){
    console.log(error.message)
  }
}
exports.querydelete= async (req,res)=>{
  try{
    const id=req.params.id
   await Query.findByIdAndDelete(id)
    res.redirect('/admin/query')
  }catch(error){
    console.log(error.message)
  }
}
exports.queryform= async (req,res)=>{
  try{
    const  username=req.session.username
    const id=req.params.id
   const record=await Query.findById(id)
    res.render('admin/queryform.ejs',{username,record})
  }catch(error){
    console.log(error.message)
  }
}
exports.emailsend= async (req,res)=>{
 try{
     
  if(req.file){
        var attachmentpath=req.file.path      
        var {emailto,emailfrom,subject,body}=req.body   
  }else{
     var {emailto,emailfrom,subject,body}=req.body   
  }
    const id=req.params.id
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user: "kumawatpravin4566@gmail.com",
          pass: process.env.EMAIL_PASSWORD,
        },        
      });
      console.log('connected to gamil smtp server')

      const info = await transporter.sendMail({
        from: emailfrom, // sender address
        to: emailto, // list of receivers
        subject: subject, // Subject line
        text: body, // plain text body
        //html: "<b>Hello world?</b>", // html body       
        attachments:[{
          path:attachmentpath
        }]
      });
      await Query.findByIdAndUpdate(id,{status:'Replied'})
       res.redirect('/admin/query')
      console.log('mail sent')
    }catch(error){
      console.log(error.message)
    }
}