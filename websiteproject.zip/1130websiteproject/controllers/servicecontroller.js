const Service=require('../models/service')
const Address=require('../models/address')

exports.serviceselection= async (req,res)=>{
    try{
   const username=req.session.username
   const record=await Service.find().sort({createDate:-1})
   const totalservice=await Service.count()
   const totalUnpublished=await Service.count({status:'Unpublished'})
   const totalPublished=await Service.count({status:'Published'})
   //console.log(totalservice)
   res.render('admin/service.ejs',{username,record,totalPublished,totalUnpublished,totalservice})
}catch(error){
    console.log(error.message)
}
}
exports.serviceform=(req,res)=>{
    try{
    const username=req.session.username
    res.render('admin/serviceform.ejs',{username})
    }catch(error){
        console.log(error.message)
    }
}
exports.serviceadd=(req,res)=>{
    const filename=req.file.filename
    try{
    const{title,desc,mdetail}=req.body
      const currentDate=new Date()
   const record=new Service({title:title,desc:desc,moredetails:mdetail,img:filename,createDate:currentDate})
     record.save()
     res.redirect('/admin/service')
     //console.log(record)
    }catch(error){
        console.log(error.message)
        res.redirect('/admin/service')
    }
}
exports.servicedelete= async (req,res)=>{
    try{
    const id=req.params.id
   await Service.findByIdAndDelete(id)
   res.redirect('/admin/service')
    }catch(error){
        console.log(error.message)
        res.redirect('/admin/service')
    }
}
exports.statusupdate= async (req,res)=>{
    try{
    const id=req.params.id
   const record=await Service.findById(req.params.id)
   //console.log(record)
    let newstatus=null
   if(record.status=='Unpublished'){
        newstatus='Published'
   }else{
        newstatus='Unpublished'
   }
   await Service.findByIdAndUpdate(id,{status:newstatus})
   res.redirect('/admin/service')
   }catch(error){
    console.log(error.message)
    res.redirect('/admin/service')
   }
}
exports.searchstatus= async (req,res)=>{
    try{
    const username=req.session.username
    const {searchinput}=req.body
    const totalservice=await Service.count()
   const totalUnpublished=await Service.count({status:'Unpublished'})
   const totalPublished=await Service.count({status:'Published'})  
  if(searchinput!==''){
    var  record= await Service.find({status:searchinput})
  }else{
       record=await Service.find({status:{$in:['Unpublished','Published']}})
  }
   res.render('admin/service.ejs',{username,record,totalPublished,totalUnpublished,totalservice})
    }catch(error){
        console.log(error.message)
    }
}
exports.servicemoredetails= async (req,res)=>{
    try{
     const id=req.params.id
    const record=await Service.findById(id)
     const addressrecord=await Address.findOne()
     res.render('servicedetails.ejs',{record,addressrecord})
    }catch(error){
        console.log(error.message)
    }
}