const Address=require('../models/address')

exports.addressselection= async (req,res)=>{
    try{
    const message=req.params.message
    const username=req.session.username
    const record=await Address.findOne()
    res.render('admin/address.ejs',{username,record,message})
    }catch(error){
        console.log(error.message)
    }
}
exports.updateform= async (req,res)=>{
    try{
    const id=req.params.id
    const username=req.session.username
    const record=await Address.findById(id)
    res.render('admin/addressform.ejs',{username,record,message:''})
    }catch(error){
        console.log(error.message)
    }
}
exports.addressupdate= async (req,res)=>{  
    try{
    const id=req.params.id 
    const username=req.session.username
    const record=await Address.findById(id)  
    let message='Successfully Update' 
    const {add,tel,whats,mob,email,link,twit,snap,insta}=req.body
    await Address.findByIdAndUpdate(id,{address:add,telephone:tel,whatsapp:whats,mobile:mob,email:email,linkedin:link,twitter:twit,snapchat:snap,instagram:insta})
    //console.log(req.body)
    //res.render('admin/addressform.ejs',{username,record,message:'Successfully Update'})
    res.redirect(`/admin/address/${message}`)
    }catch(error){
        console.log(error.message)
    }
}